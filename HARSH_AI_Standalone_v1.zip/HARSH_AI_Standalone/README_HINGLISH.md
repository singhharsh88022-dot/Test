# HARSH AI — Standalone Project

Ye project sirf HARSH AI ke liye hai. HA Editing aur Digital Tools website ka code isme include nahi hai.

## Is build mein kya hai
- Purple dark mobile-first AI chat UI
- Gemini 2.5 Flash backend (API key server-side secret)
- Conversation context + local chat history
- Image understanding + PDF/TXT/MD/CSV upload (10 MB app-side limit)
- Browser voice-to-text (browser support/microphone permission required)
- Optional Google Search grounding toggle
- Image Studio UI + Gemini image-generation endpoint (model access/quota dependent)
- PWA install support
- Capacitor Android wrapper configuration

## Zaroori sach / limitations
1. Gemini API key aur deploy kiye bina AI responses nahi chalenge. API key browser code mein kabhi mat daalna.
2. Google AI Studio free quota/limits change ho sakte hain. Free use guaranteed unlimited nahi hai.
3. Gemini image generation may not be enabled for every key, model, region or free tier. If it fails, verify an image model in AI Studio and set `GEMINI_IMAGE_MODEL` on Cloudflare. The default is only a starting model name, not a promise of access.
4. Voice input uses browser speech recognition; it may require internet, microphone permission, and Chrome/Android support.
5. Chat history is stored in this browser's local storage. There is no cross-device account sync in this version.
6. The Android APK is not prebuilt in this ZIP. Build it with Android Studio/Android SDK after setting up the hosted URL or packaging the local web assets.

## Cloudflare Pages deploy (recommended)
1. Extract this ZIP. Create a new GitHub repository and upload the project contents.
2. In Cloudflare Dashboard: Workers & Pages → Create → Pages → Connect to Git.
3. Framework preset: None. Build command: leave blank. Build output directory: `public`.
4. Deploy. Cloudflare Pages Functions in the `functions/` folder are deployed with the project.
5. Open your Pages project → Settings → Variables and Secrets → Add secret:
   - Name: `GEMINI_API_KEY`
   - Value: your key from https://aistudio.google.com/apikey
6. Optional secret/variable `GEMINI_IMAGE_MODEL`: only set this to a model confirmed available to your key.
7. Redeploy after adding secrets. Open `/api/health`; it should show `configured: true`.
8. Open your app URL and test a simple prompt, image/PDF upload, then enable Web Search and test a current question.

## Local development
- Install Node.js 20+ (Wrangler supports modern Node).
- Run `npm install`
- Run `npx wrangler pages dev public`
- Set secret for local dev in `.dev.vars` (do not upload this file):
  `GEMINI_API_KEY=your_key_here`

## Android APK (requires a computer with Android Studio)
Option A — package local web files (the API still needs the deployed server):
1. Deploy the web app to Cloudflare Pages first and copy its HTTPS URL.
2. Edit `capacitor.config.json` and add `"server": { "url": "https://YOUR-PAGES-URL.pages.dev", "cleartext": false }` inside the config object (replace the URL with your real Pages URL). This makes the Android shell load the deployed app and its API.
3. Run `npm install`
4. Run `npx cap add android` (only once)
5. Run `npx cap sync android`
6. Run `npx cap open android`
7. In Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).
8. Install/test the generated debug APK. For public distribution, create a signed release APK/AAB.

Option B — app shell pointing at the deployed site:
- After the Pages URL is ready, use Capacitor's `server.url` setting with your HTTPS app URL and keep the URL trusted. Do not commit API secrets.
- For a public store release, follow Capacitor Android signing and Google Play requirements.

## Security checklist before public launch
- Keep `GEMINI_API_KEY` only as a Cloudflare secret.
- Add Cloudflare rate limiting / Turnstile and abuse controls before sharing publicly; otherwise strangers can consume your API quota.
- Set spending/quota alerts in Google AI Studio / Google Cloud if available.
- Add privacy policy and terms suitable for the final deployment and data handling.
- Do not promise unlimited free usage. Apply sensible limits per visitor.

## Android APK build without your own computer (GitHub Actions)
1. Deploy HARSH AI to Cloudflare Pages first.
2. Upload this project to a GitHub repository.
3. GitHub repo → Settings → Secrets and variables → Actions → Variables → New repository variable.
   - Name: `HARSH_AI_URL`
   - Value: your deployed HTTPS Pages URL (for example `https://your-project.pages.dev`).
4. Open the repository's Actions tab → `Build HARSH AI Android APK` → Run workflow.
5. When the run succeeds, open that run and download the `HARSH-AI-debug-APK` artifact. Extract it and install `app-debug.apk` on Android (allow install from that source if Android asks).

This is a debug APK for testing. A signed release APK/AAB needs a signing key and a separate release workflow before public distribution.
