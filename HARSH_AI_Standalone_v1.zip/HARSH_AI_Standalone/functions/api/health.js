export async function onRequestGet({ env }) {
  return Response.json({ ok: true, configured: Boolean(env.GEMINI_API_KEY) });
}
