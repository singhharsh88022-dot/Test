function err(message,status=400){return Response.json({ok:false,error:message},{status});}
export async function onRequestPost({request,env}){
 if(!env.GEMINI_API_KEY)return err('Gemini API key is not configured on the server.',503);
 let body;try{body=await request.json()}catch{return err('Invalid request body.')}
 const prompt=String(body.prompt||'').trim().slice(0,3000);if(!prompt)return err('Describe the image you want.');
 // Image generation is model/region/quota dependent. Configure GEMINI_IMAGE_MODEL only after confirming access in AI Studio.
 const model=env.GEMINI_IMAGE_MODEL||'gemini-2.0-flash-preview-image-generation';
 try{const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(env.GEMINI_API_KEY)}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:`Generate an image based on this description: ${prompt}`}]}],generationConfig:{responseModalities:['TEXT','IMAGE']}})});const d=await r.json();if(!r.ok)return err(d?.error?.message||'Image generation is not enabled for this API key/model. Check Gemini image model access and quota.',r.status===429?429:502);const parts=d.candidates?.[0]?.content?.parts||[];const image=parts.find(p=>p.inlineData||p.inline_data);const payload=image?.inlineData||image?.inline_data;if(!payload?.data)return err('This Gemini model did not return an image. Configure an image-generation model available to your account.',502);return Response.json({ok:true,image:payload.data,mimeType:payload.mimeType||payload.mime_type||'image/png'});}catch{return err('Could not reach Gemini image generation.',502)}
}
